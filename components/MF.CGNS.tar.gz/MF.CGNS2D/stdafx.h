#include <wx/wxprec.h>

#include <wx/intl.h>
#include <wx/log.h>

#include <wx/filename.h>

#include "wx/fileconf.h"

#include <iostream>
#include <string>
#include <vector>
#include <map>